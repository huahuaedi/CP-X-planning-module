"""Scenario package for town5_scenario_3."""
