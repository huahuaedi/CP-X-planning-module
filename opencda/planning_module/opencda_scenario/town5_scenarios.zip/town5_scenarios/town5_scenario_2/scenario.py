"""
Scenario-local logic for town5_scenario_2.

This scenario intentionally reuses the town10_scenario_5 runtime behavior so
vehicle, hazard, VRU, and control-message handling stay identical while the
scenario identity, defaults, and log labels remain local to Town05.
"""

from __future__ import annotations

from contextlib import contextmanager
from functools import wraps
from typing import Any, Callable

from opencda_scenario.town10_scenario_5 import scenario as _impl


SCENARIO_NAME = "town5_scenario_2"
DEFAULT_CP_MESSAGE_PATH = _impl.DEFAULT_CP_MESSAGE_PATH


def _info(message: str) -> None:
    print(f"[TOWN5 SCENARIO 2] {message}")


def _warning(message: str) -> None:
    print(f"[TOWN5 SCENARIO 2] Warning: {message}")


@contextmanager
def _patched_identity():
    original_scenario_name = _impl.SCENARIO_NAME
    original_info = _impl._info
    original_warning = _impl._warning
    _impl.SCENARIO_NAME = SCENARIO_NAME
    _impl._info = _info
    _impl._warning = _warning
    try:
        yield
    finally:
        _impl.SCENARIO_NAME = original_scenario_name
        _impl._info = original_info
        _impl._warning = original_warning


def _wrap_runtime_function(function_name: str) -> Callable[..., Any]:
    impl_function = getattr(_impl, function_name)

    @wraps(impl_function)
    def _wrapped(*args, **kwargs):
        with _patched_identity():
            return impl_function(*args, **kwargs)

    return _wrapped


initialize_runtime = _wrap_runtime_function("initialize_runtime")
maybe_replan_global_route = _wrap_runtime_function("maybe_replan_global_route")
filter_dynamic_obstacle_snapshots = _wrap_runtime_function(
    "filter_dynamic_obstacle_snapshots"
)


def __getattr__(name: str) -> Any:
    return getattr(_impl, name)


__all__ = [
    "SCENARIO_NAME",
    "DEFAULT_CP_MESSAGE_PATH",
    "initialize_runtime",
    "maybe_replan_global_route",
    "filter_dynamic_obstacle_snapshots",
]
