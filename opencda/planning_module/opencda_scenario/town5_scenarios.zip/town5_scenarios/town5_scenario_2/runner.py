"""
Scenario-specific runner wrapper for town5_scenario_2.
"""

from __future__ import annotations

from contextlib import contextmanager

from opencda_scenario.town10_scenario_5 import runner as _impl


SCENARIO_NAME = "town5_scenario_2"


def _info(message: str) -> None:
    print(f"[TOWN5 SCENARIO 2] {message}")


def _warning(message: str) -> None:
    print(f"[TOWN5 SCENARIO 2] Warning: {message}")


@contextmanager
def _patched_logging():
    original_info = _impl._info
    original_warning = _impl._warning
    _impl._info = _info
    _impl._warning = _warning
    try:
        yield
    finally:
        _impl._info = original_info
        _impl._warning = original_warning


def run_loaded_world(client, world, scenario_cfg, carla) -> int:
    with _patched_logging():
        return int(
            _impl.run_loaded_world(
                client=client,
                world=world,
                scenario_cfg=scenario_cfg,
                carla=carla,
            )
        )
